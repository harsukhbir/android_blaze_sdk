package com.blazeautomation.connected_ls_sample.model;

public class HubInstallation {
}
