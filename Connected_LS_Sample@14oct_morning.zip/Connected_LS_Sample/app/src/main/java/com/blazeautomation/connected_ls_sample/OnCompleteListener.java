package com.blazeautomation.connected_ls_sample;

/**
 * Created by RAHUL on 8/27/2018.
 */
public interface OnCompleteListener {
    void onCompleted();
}
