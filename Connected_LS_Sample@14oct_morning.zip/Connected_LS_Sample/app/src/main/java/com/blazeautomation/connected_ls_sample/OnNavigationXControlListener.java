package com.blazeautomation.connected_ls_sample;

import androidx.navigation.NavController;

public interface OnNavigationXControlListener {
    NavController getNavController();
}
